# Guide — Mon site EcoDesign

Ce guide t'explique comment mettre ton site en ligne gratuitement (via GitHub Pages), et comment le modifier toi-même ensuite, sans coder.

## 1. Ce que tu as reçu

Un dossier de fichiers qui forme un site web complet :

- `index.html` — la page d'accueil (profil, pourquoi m'engager, projets, articles, témoignages, contact)
- `portfolio.html` — la liste de tous tes projets
- `portfolio-projet.html` — le modèle de page pour un projet (le contenu change selon `?id=...` dans l'URL)
- `articles.html` — la liste de tous tes articles
- `articles-article.html` — le modèle de page pour un article
- `data/content.fr.js` et `data/content.en.js` — **tout le texte du site**, en français et en anglais. C'est le seul dossier que tu auras besoin de modifier au quotidien.
- `images/` — ton logo et ta favicon (icône d'onglet). Tu peux y ajouter ta photo (`portrait.jpg`).
- `documents/` — dépose ici tes CV en PDF (voir le fichier `README.txt` dedans).
- `css/style.css` — les couleurs et polices, reprises de ta charte graphique EcoDesign.
- `js/main.js` — le code qui assemble tout. Tu n'as normalement jamais besoin d'y toucher.

Le site est bilingue : un bouton FR/EN en haut à droite bascule tout le contenu.

## 2. Mettre le site en ligne avec GitHub Pages (gratuit)

### Étape 1 — Créer un compte GitHub
Va sur [github.com](https://github.com) → "Sign up" → crée un compte gratuit avec ton email.

### Étape 2 — Créer un dépôt (repository)
1. Une fois connectée, clique sur le bouton **"+"** en haut à droite → **"New repository"**.
2. Nom du dépôt : `estee-desanctis-portfolio` (ou ce que tu veux).
3. Coche **Public**.
4. Ne coche **rien d'autre** (pas de README, pas de .gitignore).
5. Clique **"Create repository"**.

### Étape 3 — Envoyer tes fichiers (aucune ligne de commande nécessaire)
1. Sur la page du dépôt fraîchement créé, clique sur le lien **"uploading an existing file"**.
2. Glisse-dépose **tout le contenu du dossier** que je t'ai fourni (tous les fichiers et sous-dossiers : `index.html`, `css/`, `js/`, `data/`, `images/`, `documents/`, etc.) dans la zone de dépôt.
   - Astuce : glisse les dossiers entiers (`css`, `js`, `data`, `images`, `documents`) un par un si le glisser-déposer groupé ne fonctionne pas du premier coup — GitHub recrée l'arborescence automatiquement.
3. En bas de page, dans "Commit changes", laisse le message par défaut et clique **"Commit changes"**.

### Étape 4 — Activer l'hébergement (GitHub Pages)
1. Dans ton dépôt, va dans l'onglet **"Settings"**.
2. Dans le menu de gauche, clique sur **"Pages"**.
3. Sous "Build and deployment" → "Source", choisis **"Deploy from a branch"**.
4. Sous "Branch", choisis **`main`** et le dossier **`/ (root)`**, puis clique **"Save"**.
5. Patiente 1 à 2 minutes, puis rafraîchis la page. Une bannière verte affiche l'adresse de ton site, du type :

   `https://ton-pseudo.github.io/estee-desanctis-portfolio/`

C'est ton site, en ligne et gratuit. 🎉

### Étape 5 (optionnel) — Nom de domaine personnalisé
Si tu achètes un jour un domaine (ex. `estee-desanctis.com`), tu pourras le connecter dans ce même écran "Pages" → "Custom domain". Pas obligatoire pour démarrer.

## 3. Modifier le contenu toi-même (sans coder)

Tout le texte du site vit dans deux fichiers : `data/content.fr.js` (français) et `data/content.en.js` (anglais). Ce sont des fichiers texte : tu n'as qu'à changer ce qui est **entre guillemets**, sans toucher au reste (virgules, accolades, crochets).

### Éditer directement sur GitHub (le plus simple)
1. Sur ton dépôt GitHub, ouvre `data/content.fr.js`.
2. Clique sur l'icône crayon (✏️) en haut à droite du fichier.
3. Modifie le texte que tu veux (par exemple ta bio, un titre, une phrase de témoignage).
4. En bas de page, clique **"Commit changes"**.
5. Le site se met à jour automatiquement en 30 secondes à 1 minute, à la même adresse.

Fais la même chose sur `content.en.js` pour la version anglaise.

### Ajouter un nouveau projet
Dans `data/content.fr.js` (et `content.en.js`), repère le bloc `"projects": [ ... ]`. Copie un bloc `{ ... }` existant (par exemple celui de `"dualsun"`), colle-le juste avant le `]` de fermeture, ajoute une virgule entre les deux blocs, puis remplace :
- `"id"` par un identifiant unique sans espace (ex. `"mon-nouveau-projet"`)
- tous les champs texte (`title`, `subtitle`, `challenge`, `role`, `results`, etc.)

Le projet apparaîtra automatiquement sur la page d'accueil et sur `portfolio.html`, avec sa propre page de détail accessible via `portfolio-projet.html?id=mon-nouveau-projet`.

### Ajouter un nouvel article
Même principe dans le bloc `"articles": [ ... ]` : copie un article existant, change `"id"`, `"date"`, `"title"`, `"excerpt"` et `"body"`.

### Ajouter un témoignage
Dans le bloc `"testimonials": [ ... ]` : copie un bloc, change `"quote"`, `"name"` et `"role"`.

### Changer ta photo
Renomme ta photo en `portrait.jpg` et dépose-la dans le dossier `images/` (remplace le fichier s'il existe déjà, ou ajoute-le simplement — il apparaîtra automatiquement dans le cadre en haut de la page d'accueil).

### Ajouter tes CV en PDF
Dépose tes fichiers PDF dans le dossier `documents/` avec les noms indiqués dans `documents/README.txt`. Le bouton "Télécharger mon CV" fonctionnera alors directement.

## 4. Besoin d'aide pour une modification ?

Tu peux toujours revenir me voir avec une demande du type "ajoute ce nouveau projet : ..." ou "change ma bio pour dire que...", et je modifierai les fichiers pour toi. Il te suffira ensuite de les recoller sur GitHub (étape 3) — ou, si tu préfères, je peux te guider pour connecter Git en ligne de commande plus tard afin que les mises à jour soient encore plus rapides.

## 5. Résumé express

1. Compte GitHub → nouveau dépôt public.
2. Glisser-déposer tous les fichiers du site.
3. Settings → Pages → Deploy from branch → `main` / root → Save.
4. Ton site est en ligne.
5. Pour modifier : édite `data/content.fr.js` / `content.en.js` directement sur GitHub, "Commit changes", et c'est en ligne en 1 minute.
